#!/bin/bash
# backup_full.sh - Backup de un directorio con la fecha en un .tar.gz

ayuda () {
	echo "Uso: $0 ORIGEN DESTINO"
	echo " ORIGEN: directorio a backupear (ej: /var/log)"
	echo " Destino: donde se guarda el backup (ej: /backup_dir)"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo " crea /backup_dir/log_bkp_AAAAMMDD.tar.gz"
	echo "Opciones: -help muestra esta ayuda"
}

# 5.5 Opcion de ayuda
if [[ $1 == "-help" ]]; then
	ayuda
	exit 0
fi

# 5.4 Argumentos: origen y destino
if [[ $# -ne 2 ]]; then
	echo "Error: se debe indicar ORIGEN y DESTINO"
	ayuda
	exit 2
fi

ORIGEN=$1
DESTINO=$2

# 5.6 Validar que origen y destino esten disponible
if [[ ! -d $ORIGEN ]]; then
	echo "Error: el origen $ORIGEN no existe o no esta disponible"
	exit 1
fi

if [[ -z $(ls $ORIGEN) ]]; then
	echo "Error: el origen $ORIGEN esta vacio o no esta montado"
	exit 1
fi

if [[ ! -d $DESTINO ]]; then
	echo "Error: el destino $DESTINO no existe"
	exit 1
fi

df -h | grep $DESTINO

if [[ $? -ne 0 ]]; then
	echo "Error: el destino $DESTINO no esta montado"
	exit 1
fi

# 5.2 Nombre con la fecha AAAAMMDD
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)
ARCHIVO=${NOMBRE}_bkp_${FECHA}.tar.gz

# 5.3 Crear el backup en el destino
tar -czf $DESTINO/$ARCHIVO $ORIGEN
if [[ $? -eq 0 ]]; then
	echo "Backup OK: $DESTINO/$ARCHIVO"
	exit 0
else
	echo "Error: no se pudo crear el backup"
	exit 1
fi


