history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
clean
clear
lsb_release -a
cat -etc-debian_version
clear
lsb_release -a
cat /etc/debian_version
hostnamectl --version
clear
hostnamectl set-hostname TPServer
cat /etc/hostname
clear
cat /etc/hosts
vim /etc/hosts
clear
cat /etc/hosts
vim /etc/hosts
clear
cat /etc/hosts
vim /etc/hosts
clear
cat /etc/hosts
ls -l /etc/hosts
vim /etc/hosts
jobs
fg
jobs
clear
cat /etc/hosts
ls -l /etc/hosts
vim /etc/hosts
cat /etc/hosts
clear
cat /etc/hosts
cat /etc/hostname
exit
exit
clear
cat /etc/apt/sources.list
df -h
clear
apt update
ip a
clear
ip a
ip routes
clear
ip routes
ip routeclear
clear
ip a
 ip route
ping 8.8.8.8
clear
ip a
ip route
ping deb.debian.org
clear
apt update
clear
cp /etc/apt/sources.list /etc/apt/spurces.list.bkp
vim /etc/apt/sources.list
clear
cat /etc/apt/sources.list
mv /etc/apt/spurces.list.bkp /etc/apt/sources.list.bkp
ls /etc/apt
clear
apt update
clear
apt upgrade
clear
vim /etc/apt/sources.list
clear
cat /etc/apt/sources.list
clear
apt update
clear
apt upgrade
clear
apt autoremove
cat /etc/debian_version
vim /etc/apt/sources.list
clear
cat /etc/apt/sources.list
apt update
clear
apt
clear
apt full-upgrade
clear
ls -l /dev/disk/by-id/
clear
debconf-show grub-pc
ls -l /dev/disk/by-id/
clear
grep -i "configuration file" /var/log/apt/term.log
find /etc -name "*.dpkg-*"
debconf-show libc
debconf-show libc6
clear
reboot
lsb_release -a
cat /etc/debian_version
poweroff
cat /root/Material_Adicional_TPVMCA/clave_privada.txt
exit
exit
clear
systemctl status apache2.service
less /root/Material_Adicional_TPVMCA/index.php
clear
apt update
apt install apache2
clear
apt install php-common libapache2-mod-php php-cli
clear
apt install php-mysql
clear
systemctl status apache2.service
php -v
clear
ls -l /var/www/html
ls -l
clear
cat /etc/apache2/mods-enable/dir.conf
clear
cat /etc/apache2/mods-enabled/dir.conf
clear
mv /var/www/html/index.html /var/www/html/index.html.bkp
cp /root/Material_Adicional_TPVMCA/logo.png
clear
cp /root/Material_Adicional_TPVMCA/logo.php /var/www/html/
clear
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
clear
ls -l /var/www/html
clear
tail /var/log/apache2/error.log
clear
systemctl status mariadb.service
clear
less /root/Material_Adicional_TPMCA/db.sqp
clear
less /root/Material_Adicional_TPMCA/db.sql
clear
less /root/Material_Adicional_TPVMCA/db.sql
clear
cat /etc/default/keyboard
clear
apt install mariadb-server
clear
systemctl status mariadb.service
clear
mariadb
clear
mariadb
clear
tail /var/log/apache2/error.log
clear
apt install php-mysql
clear
systemctl restart apache2.service
poweroff
clear
ip a
ip route
clear
ip route
clear
cat /etc/network/interfaces
clear
ipconfig
clear[3~
ping 192.168.0.200
clear
poweroff
clear
cp /etc/network/interfaces /etc/network/interfaces.bkp
vim /etc/network/interfaces
clear
systemctl restart networking.service
clear
ip a
clear
ip rpute
clear
ip route
clear
ping 8.8.8.8
clear
apt update
clear
poweroff
clear
lsblk
clear
sdc
clear
fdisk /dev/sdc
clear
lsblk
clear
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
clear
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
clear
less /etc/apache2/sites-available/000-default.conf
clear
clear
less /etc/apache2/apache2.conf
clear
mv /var/www/html/index.php /www_dir/
mv /var/www/html/logo.png /www_dir/
ls -l /www_dir
ls -l /var/www/html
clear
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/available/000-default.confg.bkp
clear
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/available/000-default.conf.bkp
clear
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bkp
vim /etc/apache2/sites-available/000-default.conf
clear
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bkp
vim /etc/apache2/apache2.conf
clear
systemctl status apache2.service
clear
systemctl reload apache2.service
systemctl status apache2.service
clear
cat /etc/fstab
cp /etc/fstab /etc/fstab.bkp
clear
vim /etc/fstab
clear
umount /www_dir
umount /backup_dir
df -h
mount -a
df -h
clear
shutdown -r now
clear
df -h
ip a
clear
cat /proc/particiones
clear
cat /proc/partitions
cat /proc/partitions > /opt/particion
ls -l /opt
cat /proc/particion
clear
cat /opt/particion
poweroff
